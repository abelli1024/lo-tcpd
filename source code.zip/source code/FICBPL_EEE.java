package Point1;
import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.IntStream;


public class FICBPL_EEE {
    String CoverageFile;
    int[][] CoverageMatrix;
    int TSNum=0;  //用例数量
    int STNum=0;  //组合数量
    ArrayList<Integer> SelectedTS = new ArrayList<Integer>();
    ArrayList<Integer> CandidateTS = new ArrayList<Integer>();
    int[] StCoveredNum; //每条组合被覆盖次数
    int[] OrderStCoveredNum;
    int MaxIndex=-1;
    int depth;
    List<List<Integer>> maxIndexList=new ArrayList<>();
    Set<Integer> maxIndexSet=new HashSet<Integer>();
    public FICBPL_EEE(String CoverageFile, int depth){
        this.CoverageFile=CoverageFile;
        this.depth = depth;
    }

    /**
     * 读取文件，生成CoverageMatrix矩阵
     */
    public void getCoverageMatrix(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(CoverageFile));
            ArrayList<String> tempAl = new ArrayList<String>();
            String line;
            while((line = br.readLine()) != null){
                line = line.trim().replaceAll(" ","");
                if(STNum == 0){
                    STNum = line.length();
                }else if(STNum != line.length()){
                    System.out.println("ERROR: The line from Coverage Matrix File is WORNG.\n"+line);
                    System.exit(1);
                }
                tempAl.add(line);
            }
            TSNum=tempAl.size();
            //初始化CoverageMatrix
            this.CoverageMatrix = new int[TSNum][STNum];
            for(int i=0; i<TSNum; i++){
                char[] tempCoverage = tempAl.get(i).toCharArray();
                for (int j=0; j<tempCoverage.length;j++){
                    CoverageMatrix[i][j] = tempCoverage[j] - '0';
                }
            }

            for (int i=0;i<TSNum;i++){ CandidateTS.add(i); }

            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public int[] getSelectedTS(){
        this.getCoverageMatrix();
        StCoveredNum=new int[STNum];

        while (CandidateTS.size()>0){
            OrderStCoveredNum = StCoveredNum.clone();
            Arrays.sort(OrderStCoveredNum);
            int[] sortedIndices = IntStream.range(0, StCoveredNum.length)
                    .boxed().sorted((i, j) -> StCoveredNum[i] - StCoveredNum[j])
                    .mapToInt(ele -> ele).toArray();
            int[] q = computeQ(OrderStCoveredNum);
            int[] w ;
            int[] bestW = new int[q.length];
            for(int i=0;i<CandidateTS.size();i++){
                int test_index = CandidateTS.get(i);
                int[] oc = computeOC(CoverageMatrix[test_index], sortedIndices);
                w = computeW(oc,q);
                int tag = compareLexi(bestW,w);
                if (tag > -1){
                    if (tag == 1){
                        maxIndexList.clear();
                        maxIndexSet.clear();
                    }
                    List<Integer> tempMaxIndexList=new ArrayList<>();
                    tempMaxIndexList.add(test_index);
                    maxIndexList.add(tempMaxIndexList);
                    maxIndexSet.add(test_index);
                    bestW =w.clone();
                }
            }

            int temp_depth = depth;
            if (CandidateTS.size() < depth){
                temp_depth = CandidateTS.size();
            }
            while (maxIndexSet.size()!=1 && temp_depth>1){//大于1因为之前已经有一次了
                maxIndexSet.clear();
                List<List<Integer>> tempMaxIndexList=new ArrayList<>();
                //初始化最优值
                int[] tempStCoveredNum1 =StCoveredNum.clone();
                for (int testIndex : maxIndexList.get(0)){
                    tempStCoveredNum1 = updateStCoveredNum(tempStCoveredNum1, CoverageMatrix[testIndex]);
                }
                Arrays.sort(tempStCoveredNum1);
                int[] tempbestW = new int[computeQ(tempStCoveredNum1).length];

                // 对每一种可能
                for (List<Integer> maxIndex : maxIndexList){
                    // 初始化覆盖数组和待排序用例集
                    int[] tempStCoveredNum =StCoveredNum.clone();
                    ArrayList<Integer> tempCandidateTS = new ArrayList<Integer>(CandidateTS);

                    for (int testIndex : maxIndex){
                        tempStCoveredNum = updateStCoveredNum(tempStCoveredNum, CoverageMatrix[testIndex]);
                        tempCandidateTS.remove((Integer) testIndex);
                    }
                    //计算排列和Q数组
                    int[] tempOrderStCoveredNum = tempStCoveredNum.clone();
                    Arrays.sort(tempOrderStCoveredNum);
                    int[] tempQ = computeQ(tempOrderStCoveredNum);

                    int[] finalTempStCoveredNum = tempStCoveredNum;
                    int[] tempSortedIndices = IntStream.range(0, tempStCoveredNum.length)
                            .boxed().sorted((i, j) -> finalTempStCoveredNum[i] - finalTempStCoveredNum[j])
                            .mapToInt(ele -> ele).toArray();


                    for(int i=0;i<tempCandidateTS.size();i++){
                        int test_index = tempCandidateTS.get(i);

                        int[] oc = computeOC(CoverageMatrix[test_index], tempSortedIndices);
                        int[] tempW = computeW(oc,tempQ);
                        int tag = compareLexi(tempbestW,tempW);
                        if (tag > -1){
                            if (tag == 1){
                                tempMaxIndexList.clear();
                                maxIndexSet.clear();
                            }
                            List<Integer> tempMaxIndex=new ArrayList<>();
                            tempMaxIndex.addAll(maxIndex);
                            tempMaxIndex.add(test_index);
                            tempMaxIndexList.add(tempMaxIndex);
                            maxIndexSet.add(maxIndex.get(0));
                            tempbestW =tempW.clone();
                        }
                    }
                }
                maxIndexList.clear();
                maxIndexList.addAll(tempMaxIndexList);
                temp_depth--;
            }
//            System.out.println("SelectedTS.size(): "+SelectedTS.size());
//            System.out.println("maxIndexSet.size(): "+maxIndexSet.size());
//            System.out.println(maxIndexList);
//            MaxIndex=maxIndexList.get(new Random().nextInt(maxIndexList.size())).get(0);
            ArrayList<Integer> list = new ArrayList(maxIndexSet);
            int randomIndex = new Random().nextInt(list.size());
            MaxIndex = list.get(randomIndex);

            SelectedTS.add(MaxIndex);
            CandidateTS.remove((Integer) MaxIndex);
            maxIndexList.clear();
            updateStCoveredNum(StCoveredNum, CoverageMatrix[MaxIndex]);

        }
        int[] result=new int[SelectedTS.size()];
        for(int i=0;i<SelectedTS.size();i++){
            result[i]=SelectedTS.get(i);
        }
        return result;
        // return SelectedTS;

    }

    /**
     * 将occ数组划分区域，相同值在同一区域
     * @return 返回区域数组，每个取值为该区大小
     */
    public int[] computeQ(int[] occ){
        ArrayList<Integer> qList = new ArrayList<Integer>();

        int start =0; //该区域起始值
        for(int i=1; i<occ.length; i++){//从第二个取值开始
            if (occ[i] - occ[i-1] >0){// occ已排序，所以>0和!=0一样
                qList.add(i -start) ;
                start = i;
            }
        }
        //加上最后一个
        qList.add(occ.length -start) ;

        // 输出
        int[] q=new int[qList.size()];
        for(int i=0;i<qList.size();i++){
            q[i]=qList.get(i);
        }
        return q;
    }

    /**
     * 计算该用例的权重数组
     * @param oc 该用例有序覆盖数组
     * @param q 权重分配数组
     * @return
     */
    public  int[] computeW(int[] oc,  int[] q){
        int[] w = new int[q.length]; // 权重矩阵
        int start = 0; //该区域起始下标
        for (int i =0; i< q.length; i ++){ //对每个区域
            int partitionSize = q[i]; // 该区域长度
            for (int j = start; j < start + partitionSize; j++){
                w[i] += oc[j];
            }
            start += partitionSize;
        }
        return w;
    }

    /**
     * 依据排列规则，计算用例的有序覆盖数组，c->oc
     * @param c 原始覆盖数组
     * @param sortedIndices 转换规则
     * @return 转换后覆盖数组
     */
    public int[] computeOC(int[] c, int[] sortedIndices){

        int[] oc = new int[sortedIndices.length];
        for (int i = 0; i<sortedIndices.length; i ++ ){
            oc[i] = c[sortedIndices[i]];
        }
        return oc ;
    }

    /**
     * 比较两个数组的字典大小
     * @param a1 原数组
     * @param a2 现数组
     * @return 大小标识，0：一样大；1：a2>a1；-1:a2<a1
     */
    public int compareLexi(int[] a1, int[] a2) {
        int tag = 0;
        for (int k = 0; k < a1.length; k++) {
            if (a2[k] != a1[k]) {
                tag = a2[k] > a1[k] ? 1 : -1;
                break;
            }
        }
        return tag;
    }

    /**
     * 更新语句被覆盖次数
     */
    public static int[] updateStCoveredNum(int[] StCoveredNum, int[] CoverageArray){

        for(int i=0;i<StCoveredNum.length;i++){
            StCoveredNum[i] += CoverageArray[i];
        }
        return StCoveredNum;
    }

    public static void main(String[] x){

        FICBPL_EEE ficbpl_eee = new FICBPL_EEE("Orig_Data/CoverageMatrix/gzip/gzip_1_matrix.txt",3);

        for(int i : ficbpl_eee.getSelectedTS()){
            System.out.print(i+",");
        }
    }
}
