package Point1.discard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class Lexi {
    public List<Integer> lexi(ArrayList<Integer> CandidateTS, int[] StCoveredNum, int[][]CoverageMatrix) {
        List<Integer> maxIndexList=new ArrayList<>();
        while (CandidateTS.size() > 0) {
            int[] OrderStCoveredNum = StCoveredNum.clone();
            Arrays.sort(OrderStCoveredNum);
            int[] sortedIndices = IntStream.range(0, StCoveredNum.length)
                    .boxed().sorted((i, j) -> StCoveredNum[i] - StCoveredNum[j])
                    .mapToInt(ele -> ele).toArray();
            int[] q = computeQ(OrderStCoveredNum);
            int[] w;
            int[] bestW = new int[q.length];
            for (int i = 0; i < CandidateTS.size(); i++) {
                int test_index = CandidateTS.get(i);
                int[] oc = computeOC(CoverageMatrix[test_index], sortedIndices);
                w = computeW(oc, q);
                int tag = compareLexi(bestW, w);
                if (tag == 1) {
                    maxIndexList.clear();
                    maxIndexList.add(CandidateTS.get(i));
                    bestW = w.clone();
                } else if (tag == 0) {
                    maxIndexList.add(CandidateTS.get(i));
                }
            }
        }
        return maxIndexList;
    }
    /**
     * 将occ数组划分区域，相同值在同一区域
     * @return 返回区域数组，每个取值为该区大小
     */
    public static int[] computeQ(int[] occ){
        ArrayList<Integer> qList = new ArrayList<Integer>();

        int start =0; //该区域起始值
        for(int i=1; i<occ.length; i++){//从第二个取值开始
            if (occ[i] - occ[i-1] >0){// occ已排序，所以>0和!=0一样
                qList.add(i -start) ;
                start = i;
            }
        }
        //加上最后一个
        qList.add(occ.length -start) ;

        // 输出
        int[] q=new int[qList.size()];
        for(int i=0;i<qList.size();i++){
            q[i]=qList.get(i);
        }
        return q;
    }

    /**
     * 计算该用例的权重数组
     * @param oc 该用例有序覆盖数组
     * @param q 权重分配数组
     * @return
     */
    public static  int[] computeW(int[] oc,  int[] q){
        int[] w = new int[q.length]; // 权重矩阵
        int start = 0; //该区域起始下标
        for (int i =0; i< q.length; i ++){ //对每个区域
            int partitionSize = q[i]; // 该区域长度
            for (int j = start; j < start + partitionSize; j++){
                w[i] += oc[j];
            }
            start += partitionSize;
        }
        return w;
    }

    /**
     * 依据排列规则，计算用例的有序覆盖数组，c->oc
     * @param c 原始覆盖数组
     * @param sortedIndices 转换规则
     * @return 转换后覆盖数组
     */
    public int[] computeOC(int[] c, int[] sortedIndices){

        int[] oc = new int[sortedIndices.length];
        for (int i = 0; i<sortedIndices.length; i ++ ){
            oc[i] = c[sortedIndices[i]];
        }
        return oc ;
    }

    /**
     * 比较两个数组的字典大小
     * @param a1 原数组
     * @param a2 现数组
     * @return 大小标识，0：一样大；1：a2>a1；-1:a2<a1
     */
    public int compareLexi(int[] a1, int[] a2) {
        int tag = 0;
        for (int k = 0; k < a1.length; k++) {
            if (a2[k] != a1[k]) {
                tag = a2[k] > a1[k] ? 1 : -1;
                break;
            }
        }
        return tag;
    }
}
