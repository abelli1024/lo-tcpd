package Point1.discard;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;


public class FICBPL_R {
    String CoverageFile;
    char[][] CoverageMatrix;
    int TSNum=0;  //用例数量
    int STNum=0;  //组合数量
    ArrayList<Integer> SelectedTS = new ArrayList<Integer>();
    ArrayList<Integer> CandidateTS = new ArrayList<Integer>();
    int[] StCoveredNum; //每条组合是否被覆盖
    int [] TSCoverNum; //每个用例覆盖的组合数，每次挑选用例更新
    int MaxIndex=-1;
    public FICBPL_R(String CoverageFile){
        this.CoverageFile=CoverageFile;
    }

    //读取文件，生成CoverageMatrix矩阵

    public void getCoverageMatrix(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(CoverageFile));
            ArrayList<String> tempAl = new ArrayList<String>();
            String line;
            while((line = br.readLine()) != null){
                line = line.trim().replaceAll(" ","");
                if(STNum == 0){
                    STNum = line.length();
                }else if(STNum != line.length()){
                    System.out.println("ERROR: The line from Coverage Matrix File is WORNG.\n"+line);
                    System.exit(1);
                }
                tempAl.add(line);
            }
            TSNum=tempAl.size();
            //初始化CoverageMatrix
            this.CoverageMatrix = new char[TSNum][STNum];
            for(int i=0; i<TSNum; i++){
                CoverageMatrix[i] = tempAl.get(i).toCharArray();
            }
            StCoveredNum=new int[STNum];
            TSCoverNum=new int[TSNum];

            for (int i=0;i<TSNum;i++){ CandidateTS.add(i); }

            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public int[] getSelectedTS(){
        this.getCoverageMatrix();
        // 第一个需要这边随机，不然放到里面，他是first te-breaking，所以结果很极端
        MaxIndex=CandidateTS.get(new Random().nextInt(CandidateTS.size()));
        SelectedTS.add(MaxIndex);
        CandidateTS.remove((Integer) MaxIndex);
        updateStCoveredNum();

        while (CandidateTS.size()>0){
            int[] TSValue = new int[STNum];
            for(int i=0;i<CandidateTS.size();i++){
                int test_index = CandidateTS.get(i);
                int[] temp_TSValue = new int[STNum];

                for (int j=0; j<STNum; j++){
                    char unit =CoverageMatrix[test_index][j];
                    temp_TSValue[j] = StCoveredNum[j]+ (unit-'0');
                }

                Arrays.sort(temp_TSValue);
                for (int k=0; k<STNum; k++){
                    if (temp_TSValue[k] > TSValue[k]){
                        MaxIndex= CandidateTS.get(i);
                        TSValue =temp_TSValue.clone();
                        break;
                    }else if (temp_TSValue[k] < TSValue[k]){
                        break;
                    }else {
                        if (k == STNum-1){
                            MaxIndex=CandidateTS.get(i);
                            break;
                        }
                    }
                }
            }
            SelectedTS.add(MaxIndex);
            CandidateTS.remove((Integer) MaxIndex);
            updateStCoveredNum();

        }
        int[] result=new int[SelectedTS.size()];
        for(int i=0;i<SelectedTS.size();i++){
            result[i]=SelectedTS.get(i);
        }
        return result;
        // return SelectedTS;

    }


    public void updateStCoveredNum(){
        for(int i=0;i<STNum;i++){
            if(CoverageMatrix[MaxIndex][i]=='1'){StCoveredNum[i]++;}
        }
    }

}
