package Point1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Collections;


public class Tcprandom {
    String CoverageFile;
    int[][] CoverageMatrix;
    int TSNum=0;  //用例数量
    int STNum=0;  //组合数量
    ArrayList<Integer> SelectedTS = new ArrayList<Integer>();
    ArrayList<Integer> CandidateTS = new ArrayList<Integer>();
    int[] StCoveredNum; //每条组合是否被覆盖
    int MaxIndex=-1;
    List<Integer> maxIndexList=new ArrayList<>();
    public Tcprandom(String CoverageFile){
        this.CoverageFile=CoverageFile;
    }

    /**
     * 读取文件，生成CoverageMatrix矩阵
     */
    public void getCoverageMatrix(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(CoverageFile));
            ArrayList<String> tempAl = new ArrayList<String>();
            String line;
            while((line = br.readLine()) != null){
                line = line.trim().replaceAll(" ","");
                if(STNum == 0){
                    STNum = line.length();
                }else if(STNum != line.length()){
                    System.out.println("ERROR: The line from Coverage Matrix File is WORNG.\n"+line);
                    System.exit(1);
                }
                tempAl.add(line);
            }
            TSNum=tempAl.size();
            //初始化CoverageMatrix
            this.CoverageMatrix = new int[TSNum][STNum];
            for(int i=0; i<TSNum; i++){
                char[] tempCoverage = tempAl.get(i).toCharArray();
                for (int j=0; j<tempCoverage.length;j++){
                    CoverageMatrix[i][j] = tempCoverage[j] - '0';
                }
            }

            for (int i=0;i<TSNum;i++){ CandidateTS.add(i); }

            br.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public int[] getSelectedTS(){
        this.getCoverageMatrix();
        StCoveredNum=new int[STNum];
        //System.out.println("老子天下第一");
        Collections.shuffle(CandidateTS);
        for(int i=0;i<CandidateTS.size();i++){
            SelectedTS.add(CandidateTS.get(i));
        }
        int[] result=new int[SelectedTS.size()];
        for(int i=0;i<SelectedTS.size();i++){
            result[i]=SelectedTS.get(i);
        }
        return result;
        // return SelectedTS;
    }

    /**
     * 比较两个数组的字典大小
     * @param a1 原数组
     * @param a2 现数组
     * @return 大小标识，0：一样大；1：a2>a1；-1:a2<a1
     */
    public int compareLexi(int[] a1, int[] a2) {
        int tag = 0;
        for (int k = 0; k < a1.length; k++) {
            if (a2[k] != a1[k]) {
                tag = a2[k] > a1[k] ? 1 : -1;
                break;
            }
        }
        return tag;
    }


    /**
     * 更新语句被覆盖次数
     * @param a 第一个数组
     * @param b 第二个数组
     * @return 相加后的数组
     */
    public int[] updateStCoveredNum(int[] a, int[] b){
        int[] c = a.clone();
        for(int i=0;i<a.length;i++){
            c[i] += b[i];
        }
        return c;
    }

}
